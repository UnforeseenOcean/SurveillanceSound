var Parser = function () {
return
{
initial: function(){
console.log("inside parser");	
}
}
};